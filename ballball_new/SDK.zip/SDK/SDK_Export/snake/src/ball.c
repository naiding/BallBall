/*
 * snake.c
 *
 *  Created on: 2015-1-6
 *      Author: xc
 */
#include <stdlib.h>
#include <stdio.h>
#include "ball.h"

