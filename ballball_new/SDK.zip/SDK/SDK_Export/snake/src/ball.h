/*
 * snake.h
 *
 *  Created on: 2015-1-6
 *      Author: xc
 */

#ifndef SNAKE_H_
#define SNAKE_H_


struct Node{
	int x;
	int y;
	char color;
};
typedef struct Node Ball;

#endif /* SNAKE_H_ */
