/*
 * boom.h
 *
 *  Created on: Dec 18, 2015
 *      Author: LEON
 */

#ifndef BOOM_H_
#define BOOM_H_

struct boom{
	int x;
	int y;
	char color;
	int direction;
};
typedef struct boom Boom;

#endif /* BOOM_H_ */
